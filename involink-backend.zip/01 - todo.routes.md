1. add error handling
2. add logging
3. add restore functionality to all routes
4. add get all functionality to all routes
