'use strict';

const { Role } = require('../models');

const seedRoles = async () => {
    try {
        const roles = [
            {
                "name": "admin",
                "description": "Admin role has full access to all resources",
            },
            {
                "name": "merchant",
                "description": "Merchant role has access to merchant resources",
            },
            {
                "name": "customer",
                "description": "Customer role has access to customer resources",
            }
        ];
        roles.forEach(async (role) => {
            await Role.create(role);
        });
        console.log('Roles seeded successfully');
    } catch (err) {
        console.error('Error seeding roles', err);
    }
}

module.exports = { seedRoles };