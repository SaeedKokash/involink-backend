'use strict';

const { Permission } = require('../models');

const seedPermissions = async () => {
    try {
        const permissions = [
            {
                "name": "",
                "description": "",
            },
        ];
        permissions.forEach(async (role) => {
            await Permission.create(role);
        });
        console.log('Roles seeded successfully');
    } catch (err) {
        console.error('Error seeding permissions', err);
    }
}

module.exports = { seedPermissions };