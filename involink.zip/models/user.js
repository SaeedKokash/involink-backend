// models/user.js
module.exports = (sequelize, DataTypes) => {
    const User = sequelize.define('User', {
      name: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      email: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
      },
      password: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      role: {
        type: DataTypes.ENUM('merchant', 'customer'),
        allowNull: false,
      },
    });
  
    User.associate = function(models) {
      if (User.role === 'merchant') {
        User.hasMany(models.Store, { foreignKey: 'userId' });
        User.belongsToMany(models.User, {
          through: 'MerchantCustomers',
          as: 'customers',
          foreignKey: 'merchantId',
          otherKey: 'customerId',
        });
      } else if (User.role === 'customer') {
        User.belongsToMany(models.User, {
          through: 'MerchantCustomers',
          as: 'merchants',
          foreignKey: 'customerId',
          otherKey: 'merchantId',
        });
      }
    };
  
    return User;
  };
  